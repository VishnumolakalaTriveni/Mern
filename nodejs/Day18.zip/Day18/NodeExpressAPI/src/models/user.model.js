const mongoose = require('mongoose');
const topperSchema= mongoose.Schema({
    tid:Number,
    tage:Number,
    tname: String,
    taddress:String,
    tphone:String,
    temail: String,
    tdob:Date,
    is_active:  { type: Boolean, default: true },
    is_verified:  { type: Boolean, default: false },
    is_deleted:  { type: Boolean, default: false }
}, {
    timestamps: true
});

module.exports = mongoose.model('topper', topperSchema);