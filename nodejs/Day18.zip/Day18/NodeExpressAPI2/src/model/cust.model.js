const mongoose = require('mongoose');
const CustSchema = mongoose.Schema({
    cid: Number,
    cadhar: String,
    cpanno: String,
    cdob: Date,
    is_active:  { type: Boolean, default: false },
    is_verified:  { type: Boolean, default: false },
    is_deleted:  { type: Boolean, default: false }
}, {
    timestamps: true
});

module.exports = mongoose.model('Cust', CustSchema);