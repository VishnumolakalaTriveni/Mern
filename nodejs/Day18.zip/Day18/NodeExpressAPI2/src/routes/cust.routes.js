const express = require('express')
const router = express.Router()
const userController = require('../controllers/cust.controllers');
// Retrieve all users
router.get('/', userController.custfindAll);
// Create a new user
router.post('/', userController.custcreate);
// Retrieve a single user with id
router.get('/:id', userController.custfindOne);
// Update a user with id
router.put('/:id', userController.custupdate);
// Delete a user with id
router.delete('/:id', userController.custdelete);
module.exports = router