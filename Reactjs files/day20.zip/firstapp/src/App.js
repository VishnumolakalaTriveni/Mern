import logo from './flower2.jfif';
import logo1 from './video1.mp4';
import logo2 from './audio1.mpeg';
 
/*import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header> 
    </div>
  );
}

export default App;
*/

import React,{Component} from 'react';
class Fruits extends React.Component{
  render(){
    return(
      <div className='top-container'>
      <Apple/>
      <Banana/>
      <Pineapple/>
      <Grapes/>
     
      </div>
      );
  }
}
class Apple extends React.Component{
  render(){
    return(
      <div className="image">
      <img src={logo} className="App-logo" alt="logo" />
      
      </div>

      );
    
  }
}
class Banana extends React.Component{
  render(){
    return(
      <div className="video">
      <video src={logo1} className="App-logo1" alt="logo1" controls/>
      </div>

      );
    
  }
}
class Pineapple extends React.Component{
  render(){
    return(
      <div className="audio">
      <audio src={logo2} className="App-logo2" alt="logo2" controls/>
      </div>

      );
    
  }
}
class Grapes extends React.Component{
  render(){
    return(
    <div>
    <h1> Login Form</h1>
      <form>
       <label>name:
       <input type="text"/>
       </label><br/>
       <label>email:
       <input type="text"/>
       </label><br/>
       <button>Login</button>
      </form>
</div>

      );
    
  }
}


export default Fruits;